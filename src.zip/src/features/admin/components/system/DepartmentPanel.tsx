import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Building2, Plus, X, } from 'lucide-react';

import { RootState } from '../../../../store/store';
import { upsertDepartment } from '../../../../store/slices/systemConfigSlice';
import { DepartmentSchema, Department } from '../../../../types/core/systemConfig.schema';
import { createPortal } from 'react-dom';

const DepartmentPanel: React.FC = () => {
    const dispatch = useDispatch();
    const departments = useSelector((state: RootState) => state.systemConfig.departments);
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);

    const { register, handleSubmit, reset, formState: { errors } } = useForm<Department>({
        resolver: zodResolver(DepartmentSchema.omit({ id: true })) as any,
        defaultValues: { status: 'draft', budget: 0 }
    });

    const onSubmit = (data: Department) => {
    const apiPayload = {
      code: data.code,
      name: data.name,
      budget: data.budget,
      status: data.status || 'draft'
    };
    console.log(JSON.stringify(apiPayload, null, 2));

    const newDept: Department = { ...data, id: crypto.randomUUID() };
    dispatch(upsertDepartment(newDept));
    setTimeout(() => { setIsDrawerOpen(false); reset(); }, 100);
  };

    return (
        <div className="space-y-6 animate-in fade-in duration-300">
            <div className="flex justify-between items-center">
                <div>
                    <h3 className="text-lg font-black text-slate-900">Organizational Departments</h3>
                    <p className="text-xs font-bold text-slate-500">Manage operational hubs and budget centers.</p>
                </div>
                <button onClick={() => setIsDrawerOpen(true)} className="bg-indigo-600 text-white px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-sm">
                    <Plus size={16} /> New Department
                </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {Object.values(departments).length === 0 ? (
                    <div className="col-span-full p-10 border-2 border-dashed border-slate-200 rounded-3xl text-center text-slate-400 font-bold text-sm">No departments configured yet.</div>
                ) : (
                    Object.values(departments).map(dept => (
                        <div key={dept.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex justify-between items-center group hover:border-indigo-300 transition-all">
                            <div>
                                <h4 className="text-sm font-black text-slate-900 group-hover:text-indigo-600 transition-colors">{dept.name}</h4>
                                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Code: {dept.code}</p>
                            </div>
                            <div className="text-right">
                                <span className={`px-2.5 py-1 rounded-md text-[10px] font-black uppercase tracking-widest ${dept.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>{dept.status}</span>
                                <p className="text-[11px] font-bold text-slate-500 mt-2">₹ {dept.budget.toLocaleString()}</p>
                            </div>
                        </div>
                    ))
                )}
            </div>

            {isDrawerOpen && createPortal(
                <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[9999] flex justify-end p-2 sm:p-4">
                    <div className="bg-white w-full max-w-md h-full shadow-2xl rounded-2xl overflow-hidden animate-in slide-in-from-right-8 flex flex-col">
                        <div className="p-6 border-b border-slate-100 flex justify-between bg-slate-50">
                            <h3 className="text-sm font-black text-slate-900 flex items-center gap-2"><Building2 size={16} className="text-indigo-600" /> New Department</h3>
                            <button onClick={() => setIsDrawerOpen(false)} className="text-slate-400"><X size={16} /></button>
                        </div>

                        <form onSubmit={handleSubmit(onSubmit)} className="p-6 flex-1 overflow-y-auto space-y-5">
                            <div>
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 block">Department Code *</label>
                                <input {...register('code')} placeholder="e.g. DEPT-SCI" className="w-full p-3 bg-slate-50 border-2 border-slate-200 rounded-xl text-sm font-bold uppercase outline-none focus:border-indigo-500" />
                                {errors.code && <p className="text-xs text-rose-500 mt-1 font-bold">{errors.code.message}</p>}
                            </div>
                            <div>
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 block">Department Name *</label>
                                <input {...register('name')} placeholder="e.g. Science & Technology" className="w-full p-3 bg-slate-50 border-2 border-slate-200 rounded-xl text-sm font-bold outline-none focus:border-indigo-500" />
                                {errors.name && <p className="text-xs text-rose-500 mt-1 font-bold">{errors.name.message}</p>}
                            </div>
                            <div>
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 block">Annual Budget (₹)</label>
                                <input type="number" {...register('budget', { valueAsNumber: true })} className="w-full p-3 bg-slate-50 border-2 border-slate-200 rounded-xl text-sm font-bold outline-none focus:border-indigo-500" />
                            </div>
                            <button type="submit" className="w-full bg-indigo-600 text-white p-3.5 rounded-xl font-black text-xs uppercase tracking-widest mt-4">Save Department</button>
                        </form>
                    </div>
                </div>,
                document.body
            )}
        </div>
    );
};

export default DepartmentPanel;